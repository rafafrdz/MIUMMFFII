Exercise 1, 2, 3 y 4 -> cnc.erl
Exercise 5 -> bank.erl