{-@ LIQUID "--higherorder"        @-}
{-@ LIQUID "--exactdc"            @-}
module T1118Lib1 where

import T1118Lib2 

{- data Product @-}
