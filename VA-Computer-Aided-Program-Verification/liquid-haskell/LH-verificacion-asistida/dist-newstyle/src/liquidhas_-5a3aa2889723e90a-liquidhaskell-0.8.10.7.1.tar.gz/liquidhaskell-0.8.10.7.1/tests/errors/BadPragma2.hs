{-@ LIQUID "--ghc-option=-O0" @-}

module Bad where 

i :: Int
i = 1

