
module FunClashLibLib where 
 
{-@ incr :: Nat -> Nat @-} 
incr :: Int -> Int 
incr x = x + 1 
