module Test0 () where

{-@ expression CyclicA1 Q = CyclicA1 Q @-}

