module WrapLibCode (foo) where

foo :: Int -> Int 
foo x = x + 1
