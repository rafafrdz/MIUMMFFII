module Boo where

{-@ data T = Cuthb { fldX :: Int, fldY :: Int } @-}

data T = Cuthb { fldX :: Int }
