module Test2 () where

{-@ type CyclicC = [CyclicC] @-}

