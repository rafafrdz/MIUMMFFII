#include "foo.h"
int foo(int x) {
  return x;
}
