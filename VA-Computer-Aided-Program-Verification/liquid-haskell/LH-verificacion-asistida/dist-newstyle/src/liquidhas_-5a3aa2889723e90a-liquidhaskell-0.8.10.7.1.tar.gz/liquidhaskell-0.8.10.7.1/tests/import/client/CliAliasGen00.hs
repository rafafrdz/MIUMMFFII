module CliAliasGen00 where 

import LibAliasGen00 

bar = foo 10
