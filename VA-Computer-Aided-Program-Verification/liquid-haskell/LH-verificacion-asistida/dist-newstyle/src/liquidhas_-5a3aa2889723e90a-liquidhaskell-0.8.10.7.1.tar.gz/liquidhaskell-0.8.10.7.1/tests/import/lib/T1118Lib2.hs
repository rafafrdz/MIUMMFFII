module T1118Lib2 where

data U1 p = U1
data Product f g p = Product (f p) (g p)
