{-@ LIQUID "--c-files=./wow.c" @-}

module Bad where 

i :: Int
i = 1

