-- | see: https://github.com/ucsd-progsys/liquidhaskell/issues/1169

module Bar where

{-@ data A @-}
data A = B
