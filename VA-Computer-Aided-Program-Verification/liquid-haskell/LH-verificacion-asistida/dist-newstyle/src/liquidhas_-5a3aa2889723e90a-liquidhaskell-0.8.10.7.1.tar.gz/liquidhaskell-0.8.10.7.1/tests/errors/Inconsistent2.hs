module Mismatch where

{-@ foo :: Nat @-}
foo :: Bool
foo = True
