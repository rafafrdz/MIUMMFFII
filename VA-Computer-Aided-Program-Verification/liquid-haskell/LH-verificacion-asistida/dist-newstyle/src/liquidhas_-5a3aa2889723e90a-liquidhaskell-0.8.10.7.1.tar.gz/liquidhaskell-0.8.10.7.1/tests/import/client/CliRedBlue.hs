module CliRedBlue where 

import           LibBlue 
import qualified LibRedBlue as RB 

{-@ yumyum :: _ -> Nat @-}
yumyum = RB.foo
