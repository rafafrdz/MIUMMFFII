module Test0 () where

{-@ predicate CyclicA1 Q = CyclicA1 Q @-}

