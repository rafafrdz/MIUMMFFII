int foo(int);
