{-@ LIQUID "--idirs=.." @-}

module Bad where 

i :: Int
i = 1

