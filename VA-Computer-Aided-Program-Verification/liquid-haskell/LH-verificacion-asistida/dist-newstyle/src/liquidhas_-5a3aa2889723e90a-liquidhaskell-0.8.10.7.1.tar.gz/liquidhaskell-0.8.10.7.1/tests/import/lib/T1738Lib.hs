module T1738Lib where

{-@ inline incr @-}
incr :: Int -> Int
incr x = x + 1
