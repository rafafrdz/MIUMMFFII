module GHC.Prim.Ext (module Exports) where

import "ghc-prim" GHC.Prim.Ext as Exports
