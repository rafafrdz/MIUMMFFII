module GHC.PrimopWrappers (module Exports) where

import "ghc-prim" GHC.PrimopWrappers as Exports
