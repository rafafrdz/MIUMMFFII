module GHC.Tuple (module Exports) where

import "ghc-prim" GHC.Tuple as Exports
