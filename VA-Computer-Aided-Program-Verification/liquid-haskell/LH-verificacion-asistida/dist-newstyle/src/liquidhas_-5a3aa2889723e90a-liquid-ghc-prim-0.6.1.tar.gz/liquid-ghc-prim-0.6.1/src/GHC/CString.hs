module GHC.CString (module Exports) where

import "this" GHC.Types

import "ghc-prim" GHC.CString as Exports
