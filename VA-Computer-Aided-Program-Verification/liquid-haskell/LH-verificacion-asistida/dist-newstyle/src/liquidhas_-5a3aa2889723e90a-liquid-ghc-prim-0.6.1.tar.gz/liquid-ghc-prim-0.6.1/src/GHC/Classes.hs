module GHC.Classes (module Exports) where

import GHC.Types
import "ghc-prim" GHC.Classes as Exports
