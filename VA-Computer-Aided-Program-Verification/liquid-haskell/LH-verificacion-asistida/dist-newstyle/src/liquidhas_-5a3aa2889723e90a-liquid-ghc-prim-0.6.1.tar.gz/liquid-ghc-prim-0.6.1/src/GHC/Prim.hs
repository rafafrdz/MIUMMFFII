module GHC.Prim (module Exports) where

import "ghc-prim" GHC.Prim as Exports
