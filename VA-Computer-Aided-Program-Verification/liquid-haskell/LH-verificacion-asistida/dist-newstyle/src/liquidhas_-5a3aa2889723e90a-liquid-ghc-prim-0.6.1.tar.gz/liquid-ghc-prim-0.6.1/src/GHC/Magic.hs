module GHC.Magic (module Exports) where

import "ghc-prim" GHC.Magic as Exports
