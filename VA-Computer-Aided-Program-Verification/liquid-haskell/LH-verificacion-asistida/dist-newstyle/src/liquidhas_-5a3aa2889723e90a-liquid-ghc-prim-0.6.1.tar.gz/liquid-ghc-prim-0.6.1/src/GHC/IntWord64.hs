module GHC.IntWord64 (module Exports) where

import "ghc-prim" GHC.IntWord64 as Exports
