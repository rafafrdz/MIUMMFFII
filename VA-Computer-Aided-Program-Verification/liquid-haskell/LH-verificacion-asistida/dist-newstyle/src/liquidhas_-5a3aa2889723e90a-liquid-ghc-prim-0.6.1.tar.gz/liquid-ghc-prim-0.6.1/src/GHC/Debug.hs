module GHC.Debug (module Exports) where

import "ghc-prim" GHC.Debug as Exports
