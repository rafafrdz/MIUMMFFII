module GHC.ResponseFile (module Exports) where

import "base" GHC.ResponseFile as Exports
