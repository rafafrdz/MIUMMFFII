module Data.STRef.Strict (module Exports) where

import "base" Data.STRef.Strict as Exports
