module Data.Data (module Exports) where

import "base" Data.Data as Exports
