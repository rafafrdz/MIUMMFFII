module Control.Exception ( module Exports ) where

import GHC.Base
import Control.Exception.Base

import "base" Control.Exception as Exports
