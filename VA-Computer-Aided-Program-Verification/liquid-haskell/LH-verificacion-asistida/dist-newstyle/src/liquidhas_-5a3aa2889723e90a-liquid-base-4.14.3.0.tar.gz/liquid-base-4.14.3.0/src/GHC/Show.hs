module GHC.Show (module Exports) where

import "base" GHC.Show as Exports
