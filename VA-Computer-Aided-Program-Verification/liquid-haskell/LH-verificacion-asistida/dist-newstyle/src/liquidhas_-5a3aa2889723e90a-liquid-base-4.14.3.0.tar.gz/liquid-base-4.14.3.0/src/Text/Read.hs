module Text.Read (module Exports) where

import "base" Text.Read as Exports
