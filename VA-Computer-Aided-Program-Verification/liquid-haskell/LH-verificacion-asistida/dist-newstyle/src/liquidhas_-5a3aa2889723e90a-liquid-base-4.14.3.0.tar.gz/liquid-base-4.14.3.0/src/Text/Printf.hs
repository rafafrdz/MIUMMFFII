module Text.Printf (module Exports) where

import "base" Text.Printf as Exports
