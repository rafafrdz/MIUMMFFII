module Data.Type.Coercion (module Exports) where

import "base" Data.Type.Coercion as Exports
