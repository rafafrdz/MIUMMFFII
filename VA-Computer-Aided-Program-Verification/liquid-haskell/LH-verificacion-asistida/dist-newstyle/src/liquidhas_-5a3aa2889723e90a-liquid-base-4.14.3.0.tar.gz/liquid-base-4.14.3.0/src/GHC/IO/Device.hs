module GHC.IO.Device (module Exports) where

import "base" GHC.IO.Device as Exports
