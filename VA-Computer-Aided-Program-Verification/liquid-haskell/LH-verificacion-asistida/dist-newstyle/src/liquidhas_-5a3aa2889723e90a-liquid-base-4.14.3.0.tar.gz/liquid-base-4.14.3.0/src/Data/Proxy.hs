module Data.Proxy (module Exports) where

import "base" Data.Proxy as Exports
