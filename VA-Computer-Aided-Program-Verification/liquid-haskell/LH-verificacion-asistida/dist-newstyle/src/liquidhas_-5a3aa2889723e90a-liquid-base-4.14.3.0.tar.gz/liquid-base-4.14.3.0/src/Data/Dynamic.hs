module Data.Dynamic (module Exports) where

import "base" Data.Dynamic as Exports
