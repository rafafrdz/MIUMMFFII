module Data.Functor.Classes (module Exports) where

import "base" Data.Functor.Classes as Exports
