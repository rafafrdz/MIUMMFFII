module Data.Foldable (module Exports) where

import GHC.Types
import "base" Data.Foldable as Exports
