module GHC.Natural (module Exports) where

import "base" GHC.Natural as Exports
