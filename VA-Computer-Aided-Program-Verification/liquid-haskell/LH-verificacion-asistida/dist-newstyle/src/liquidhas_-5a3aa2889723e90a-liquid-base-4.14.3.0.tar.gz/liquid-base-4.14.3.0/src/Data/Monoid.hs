module Data.Monoid (module Exports) where

import "base" Data.Monoid as Exports
