module Data.Traversable (module Exports) where

import "base" Data.Traversable as Exports
