module Text.ParserCombinators.ReadP (module Exports) where

import "base" Text.ParserCombinators.ReadP as Exports
