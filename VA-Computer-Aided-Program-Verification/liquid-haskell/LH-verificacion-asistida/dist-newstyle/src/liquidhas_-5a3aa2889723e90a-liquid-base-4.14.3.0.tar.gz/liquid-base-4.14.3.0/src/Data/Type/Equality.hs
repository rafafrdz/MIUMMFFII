module Data.Type.Equality (module Exports) where

import "base" Data.Type.Equality as Exports
