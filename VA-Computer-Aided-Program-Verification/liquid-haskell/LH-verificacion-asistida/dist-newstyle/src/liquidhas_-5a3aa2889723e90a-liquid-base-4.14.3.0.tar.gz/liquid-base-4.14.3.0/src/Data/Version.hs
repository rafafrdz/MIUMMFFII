module Data.Version (module Exports) where

import "base" Data.Version as Exports
