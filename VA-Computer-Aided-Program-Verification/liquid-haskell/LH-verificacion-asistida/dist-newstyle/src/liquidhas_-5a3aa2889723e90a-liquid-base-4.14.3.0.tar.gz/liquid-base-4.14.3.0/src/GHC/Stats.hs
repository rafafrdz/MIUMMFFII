module GHC.Stats (module Exports) where

import "base" GHC.Stats as Exports
