module GHC.Foreign (module Exports) where

import "base" GHC.Foreign as Exports
