module GHC.TypeNats (module Exports) where

import "base" GHC.TypeNats as Exports
