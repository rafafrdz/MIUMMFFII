module GHC.Char (module Exports) where

import "base" GHC.Char as Exports
