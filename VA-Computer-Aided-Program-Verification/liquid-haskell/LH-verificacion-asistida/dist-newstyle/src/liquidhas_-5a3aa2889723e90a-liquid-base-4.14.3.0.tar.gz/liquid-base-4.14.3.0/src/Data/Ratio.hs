module Data.Ratio ( module Exports ) where

import GHC.Base
import "base" Data.Ratio as Exports
