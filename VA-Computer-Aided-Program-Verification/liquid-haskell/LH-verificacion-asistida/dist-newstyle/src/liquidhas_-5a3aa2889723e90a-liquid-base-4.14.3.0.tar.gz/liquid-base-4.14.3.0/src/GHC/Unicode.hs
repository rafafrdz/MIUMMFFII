module GHC.Unicode (module Exports) where

import "base" GHC.Unicode as Exports
