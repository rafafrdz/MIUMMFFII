module Control.Concurrent.QSemN (module Exports) where

import "base" Control.Concurrent.QSemN as Exports
