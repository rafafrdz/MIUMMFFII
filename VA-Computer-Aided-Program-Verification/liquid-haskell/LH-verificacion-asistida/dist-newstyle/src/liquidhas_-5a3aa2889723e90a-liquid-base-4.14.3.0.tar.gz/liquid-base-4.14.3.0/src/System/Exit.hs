module System.Exit (module Exports) where

import "base" System.Exit as Exports
