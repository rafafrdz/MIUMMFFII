module Control.Monad.ST.Lazy.Safe (module Exports) where

import "base" Control.Monad.ST.Lazy.Safe as Exports
