module GHC.IO.Handle.Internals (module Exports) where

import "base" GHC.IO.Handle.Internals as Exports
