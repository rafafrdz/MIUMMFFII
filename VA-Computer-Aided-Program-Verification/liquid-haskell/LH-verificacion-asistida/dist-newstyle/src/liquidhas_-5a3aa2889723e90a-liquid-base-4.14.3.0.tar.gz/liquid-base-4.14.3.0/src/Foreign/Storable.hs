module Foreign.Storable (module Exports) where

import GHC.Base
import GHC.Ptr
import Foreign.Ptr
import "base" Foreign.Storable as Exports
