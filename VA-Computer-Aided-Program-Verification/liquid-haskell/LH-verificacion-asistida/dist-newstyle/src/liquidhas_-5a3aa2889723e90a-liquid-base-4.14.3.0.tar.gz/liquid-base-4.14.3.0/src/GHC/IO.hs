module GHC.IO ( module Exports ) where

import GHC.Base
import "base" GHC.IO as Exports
