module Data.String ( module Exports ) where

import GHC.Base
import "base" Data.String as Exports

