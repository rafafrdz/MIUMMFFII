module Data.Either ( module Exports ) where

import GHC.Base

import "base" Data.Either as Exports
