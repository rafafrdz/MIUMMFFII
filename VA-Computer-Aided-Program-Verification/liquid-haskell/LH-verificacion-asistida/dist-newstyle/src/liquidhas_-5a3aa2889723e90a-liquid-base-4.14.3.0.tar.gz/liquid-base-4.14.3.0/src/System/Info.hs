module System.Info (module Exports) where

import "base" System.Info as Exports
