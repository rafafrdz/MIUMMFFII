{-# LANGUAGE Trustworthy #-}
module Data.Word ( module Exports) where

import "base" Data.Word as Exports
