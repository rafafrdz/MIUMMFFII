module Data.Tuple (module Exports) where

import GHC.Base

import "base" Data.Tuple as Exports
