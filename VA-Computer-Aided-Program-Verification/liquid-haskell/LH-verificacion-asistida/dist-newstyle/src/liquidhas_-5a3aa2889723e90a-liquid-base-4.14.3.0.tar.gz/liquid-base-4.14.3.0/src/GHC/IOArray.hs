module GHC.IOArray (module Exports) where

import "base" GHC.IOArray as Exports
