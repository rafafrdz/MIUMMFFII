module GHC.IO.Buffer (module Exports) where

import "base" GHC.IO.Buffer as Exports
