module GHC.Conc.IO (module Exports) where

import "base" GHC.Conc.IO as Exports
