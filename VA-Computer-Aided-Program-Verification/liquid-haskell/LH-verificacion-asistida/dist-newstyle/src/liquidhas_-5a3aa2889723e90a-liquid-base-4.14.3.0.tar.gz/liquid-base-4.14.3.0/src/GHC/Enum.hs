module GHC.Enum (module Exports) where

import "base" GHC.Enum as Exports
