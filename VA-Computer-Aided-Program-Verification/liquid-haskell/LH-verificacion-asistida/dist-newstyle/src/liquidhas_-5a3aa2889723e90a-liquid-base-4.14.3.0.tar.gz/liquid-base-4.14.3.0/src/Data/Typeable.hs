{-# LANGUAGE Trustworthy #-}
module Data.Typeable (module Exports) where

import "base" Data.Typeable as Exports