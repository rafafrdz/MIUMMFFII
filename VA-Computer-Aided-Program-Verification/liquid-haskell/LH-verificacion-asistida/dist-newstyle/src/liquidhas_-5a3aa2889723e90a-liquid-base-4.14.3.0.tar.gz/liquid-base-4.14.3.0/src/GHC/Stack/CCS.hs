module GHC.Stack.CCS (module Exports) where

import "base" GHC.Stack.CCS as Exports
