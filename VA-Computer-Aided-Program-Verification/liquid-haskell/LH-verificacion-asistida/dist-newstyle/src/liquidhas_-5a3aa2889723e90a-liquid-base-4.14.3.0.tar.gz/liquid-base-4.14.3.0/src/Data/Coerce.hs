module Data.Coerce (module Exports) where

import "base" Data.Coerce as Exports
