module GHC.Weak (module Exports) where

import "base" GHC.Weak as Exports
