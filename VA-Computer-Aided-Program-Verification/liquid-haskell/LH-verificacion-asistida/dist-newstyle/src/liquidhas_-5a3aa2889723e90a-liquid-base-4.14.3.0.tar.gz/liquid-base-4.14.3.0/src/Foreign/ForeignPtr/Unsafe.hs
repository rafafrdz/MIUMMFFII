module Foreign.ForeignPtr.Unsafe (module Exports) where

import "base" Foreign.ForeignPtr.Unsafe as Exports
