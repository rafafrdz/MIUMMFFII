module System.IO ( module Exports ) where

import GHC.IO.Handle as Exports
import "base" System.IO as Exports
