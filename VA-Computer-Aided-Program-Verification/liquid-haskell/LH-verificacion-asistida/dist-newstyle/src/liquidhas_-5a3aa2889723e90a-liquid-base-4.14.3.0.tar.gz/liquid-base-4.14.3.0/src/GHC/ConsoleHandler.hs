module GHC.ConsoleHandler (module Exports) where

import "base" GHC.ConsoleHandler as Exports
