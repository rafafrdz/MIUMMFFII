module Foreign.Concurrent (module Exports) where

import GHC.IO
import GHC.Ptr
import GHC.ForeignPtr

import "base" Foreign.Concurrent as Exports
