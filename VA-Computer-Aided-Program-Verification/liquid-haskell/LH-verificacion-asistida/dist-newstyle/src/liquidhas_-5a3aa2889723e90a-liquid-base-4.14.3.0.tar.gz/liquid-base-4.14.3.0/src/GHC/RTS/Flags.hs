module GHC.RTS.Flags (module Exports) where

import "base" GHC.RTS.Flags as Exports
