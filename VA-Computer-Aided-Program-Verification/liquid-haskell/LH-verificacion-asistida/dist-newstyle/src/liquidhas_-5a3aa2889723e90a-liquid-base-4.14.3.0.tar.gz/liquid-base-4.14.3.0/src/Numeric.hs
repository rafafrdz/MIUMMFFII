module Numeric (module Exports) where

import "base" Numeric as Exports
