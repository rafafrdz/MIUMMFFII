module GHC.Environment (module Exports) where

import "base" GHC.Environment as Exports
