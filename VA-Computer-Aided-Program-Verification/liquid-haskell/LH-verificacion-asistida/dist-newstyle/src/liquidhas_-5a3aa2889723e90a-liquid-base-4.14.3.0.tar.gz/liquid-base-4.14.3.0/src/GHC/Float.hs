module GHC.Float (module Exports) where

import "base" GHC.Float as Exports
