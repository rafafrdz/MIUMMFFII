module Data.Type.Bool (module Exports) where

import "base" Data.Type.Bool as Exports
