module GHC.OldList (module Exports) where

import "base" GHC.OldList as Exports
