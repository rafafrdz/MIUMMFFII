module System.Console.GetOpt (module Exports) where

import "base" System.Console.GetOpt as Exports
