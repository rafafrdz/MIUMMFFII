module GHC.IO.Encoding (module Exports) where

import "base" GHC.IO.Encoding as Exports
