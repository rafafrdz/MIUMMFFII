module GHC.Storable (module Exports) where

import "base" GHC.Storable as Exports
