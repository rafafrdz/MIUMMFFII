module Data.STRef.Lazy (module Exports) where

import "base" Data.STRef.Lazy as Exports
