module Control.Monad.Fail (module Exports) where

import "base" Control.Monad.Fail as Exports
