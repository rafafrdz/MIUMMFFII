module GHC.Arr (module Exports) where

import "base" GHC.Arr as Exports
