module GHC.Profiling (module Exports) where

import "base" GHC.Profiling as Exports
