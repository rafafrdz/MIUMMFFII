module System.Mem.StableName (module Exports) where

import "base" System.Mem.StableName as Exports
