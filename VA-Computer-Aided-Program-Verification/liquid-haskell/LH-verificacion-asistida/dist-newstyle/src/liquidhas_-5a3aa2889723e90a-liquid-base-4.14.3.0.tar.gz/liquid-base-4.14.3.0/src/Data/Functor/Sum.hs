module Data.Functor.Sum (module Exports) where

import "base" Data.Functor.Sum as Exports
