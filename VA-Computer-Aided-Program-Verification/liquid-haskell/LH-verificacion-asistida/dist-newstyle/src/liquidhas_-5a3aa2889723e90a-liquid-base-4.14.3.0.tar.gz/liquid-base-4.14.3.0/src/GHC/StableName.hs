module GHC.StableName (module Exports) where

import "base" GHC.StableName as Exports
