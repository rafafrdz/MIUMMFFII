module Data.List.NonEmpty ( module Exports ) where

import Data.List
import "base" Data.List.NonEmpty as Exports
