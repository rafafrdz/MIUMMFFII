module Foreign.Marshal.Safe (module Exports) where

import "base" Foreign.Marshal.Safe as Exports
