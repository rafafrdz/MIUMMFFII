module Data.Bifoldable (module Exports) where

import "base" Data.Bifoldable as Exports
