module Foreign.Marshal.Unsafe (module Exports) where

import "base" Foreign.Marshal.Unsafe as Exports
