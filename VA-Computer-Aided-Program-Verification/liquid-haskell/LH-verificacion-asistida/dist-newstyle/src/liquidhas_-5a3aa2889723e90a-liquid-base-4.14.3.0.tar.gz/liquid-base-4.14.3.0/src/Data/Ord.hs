module Data.Ord ( module Exports) where

import "base" Data.Ord as Exports
