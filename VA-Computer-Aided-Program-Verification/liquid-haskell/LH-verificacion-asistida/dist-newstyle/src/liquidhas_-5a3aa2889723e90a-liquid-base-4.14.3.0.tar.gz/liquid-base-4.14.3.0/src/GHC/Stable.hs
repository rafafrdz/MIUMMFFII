module GHC.Stable (module Exports) where

import "base" GHC.Stable as Exports
