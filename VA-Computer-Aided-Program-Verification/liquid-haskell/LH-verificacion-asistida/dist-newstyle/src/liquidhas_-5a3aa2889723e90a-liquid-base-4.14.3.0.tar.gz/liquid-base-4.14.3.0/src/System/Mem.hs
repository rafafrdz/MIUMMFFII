module System.Mem (module Exports) where

import "base" System.Mem as Exports
