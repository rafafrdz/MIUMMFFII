module Data.Char ( module Exports ) where

import GHC.Base
import "base" Data.Char as Exports
