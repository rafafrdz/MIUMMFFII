module System.CPUTime (module Exports) where

import "base" System.CPUTime as Exports
