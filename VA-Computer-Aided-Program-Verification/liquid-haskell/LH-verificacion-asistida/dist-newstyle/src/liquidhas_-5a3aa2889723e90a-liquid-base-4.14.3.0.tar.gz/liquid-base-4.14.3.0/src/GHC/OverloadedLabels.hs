module GHC.OverloadedLabels (module Exports) where

import "base" GHC.OverloadedLabels as Exports
