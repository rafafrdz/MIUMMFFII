module Data.Functor.Contravariant (module Exports) where

import "base" Data.Functor.Contravariant as Exports
