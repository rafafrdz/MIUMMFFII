module Data.Fixed (module Exports) where

import "base" Data.Fixed as Exports
