module GHC.Exception (module Exports) where

import "base" GHC.Exception as Exports
