module GHC.Ptr ( module Exports ) where

import GHC.Types
import "base" GHC.Ptr as Exports
