module GHC.Conc.Sync (module Exports) where

import "base" GHC.Conc.Sync as Exports
