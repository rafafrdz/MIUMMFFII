module System.Environment (module Exports) where

import "base" System.Environment as Exports
