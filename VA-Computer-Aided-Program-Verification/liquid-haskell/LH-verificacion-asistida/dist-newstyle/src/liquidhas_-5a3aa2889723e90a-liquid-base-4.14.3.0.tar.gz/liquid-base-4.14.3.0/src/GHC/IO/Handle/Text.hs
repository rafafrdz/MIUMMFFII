module GHC.IO.Handle.Text (module Exports) where

import "base" GHC.IO.Handle.Text as Exports
