module GHC.Constants (module Exports) where

import "base" GHC.Constants as Exports
