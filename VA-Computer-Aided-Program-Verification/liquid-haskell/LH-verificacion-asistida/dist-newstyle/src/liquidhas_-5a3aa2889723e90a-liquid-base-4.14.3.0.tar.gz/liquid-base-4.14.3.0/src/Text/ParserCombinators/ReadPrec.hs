module Text.ParserCombinators.ReadPrec (module Exports) where

import "base" Text.ParserCombinators.ReadPrec as Exports
