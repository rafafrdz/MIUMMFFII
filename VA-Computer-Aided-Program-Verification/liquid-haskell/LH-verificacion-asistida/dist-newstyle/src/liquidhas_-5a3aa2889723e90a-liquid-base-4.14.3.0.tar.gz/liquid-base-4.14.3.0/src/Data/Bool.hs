module Data.Bool (module Exports) where

import "base" Data.Bool as Exports
