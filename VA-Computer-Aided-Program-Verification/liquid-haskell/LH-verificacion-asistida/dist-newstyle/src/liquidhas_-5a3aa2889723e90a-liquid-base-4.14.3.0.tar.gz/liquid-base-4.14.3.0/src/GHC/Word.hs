module GHC.Word (module Exports) where

import GHC.Base
import "base" GHC.Word as Exports
