module Data.Eq (module Exports) where

import "base" Data.Eq as Exports
