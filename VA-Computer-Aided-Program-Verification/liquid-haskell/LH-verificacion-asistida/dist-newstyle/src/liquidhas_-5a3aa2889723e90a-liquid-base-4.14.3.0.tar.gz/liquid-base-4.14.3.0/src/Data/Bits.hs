{-# LANGUAGE Trustworthy #-}
module Data.Bits ( module Exports ) where

import "base" Data.Bits as Exports
