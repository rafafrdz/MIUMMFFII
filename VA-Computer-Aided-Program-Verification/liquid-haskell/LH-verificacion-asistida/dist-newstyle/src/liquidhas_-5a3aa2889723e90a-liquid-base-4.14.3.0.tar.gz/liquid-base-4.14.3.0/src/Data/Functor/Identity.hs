module Data.Functor.Identity (module Exports) where

import "base" Data.Functor.Identity as Exports
