module GHC.Read (module Exports) where

import "base" GHC.Read as Exports
