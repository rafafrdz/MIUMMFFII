module Foreign.Marshal.Error (module Exports) where

import "base" Foreign.Marshal.Error as Exports
