module Debug.Trace (module Exports) where

import "base" Debug.Trace as Exports
