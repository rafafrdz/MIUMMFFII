module GHC.List (module Exports) where

import GHC.Base
import "base" GHC.List as Exports
