module GHC.IO.Encoding.UTF32 (module Exports) where

import "base" GHC.IO.Encoding.UTF32 as Exports
