module Data.Bifunctor (module Exports) where

import "base" Data.Bifunctor as Exports
