module Control.Monad.ST.Strict (module Exports) where

import "base" Control.Monad.ST.Strict as Exports
