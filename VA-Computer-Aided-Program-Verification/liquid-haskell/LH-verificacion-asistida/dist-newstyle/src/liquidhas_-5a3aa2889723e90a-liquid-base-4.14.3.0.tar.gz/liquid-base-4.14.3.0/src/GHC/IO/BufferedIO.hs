module GHC.IO.BufferedIO (module Exports) where

import "base" GHC.IO.BufferedIO as Exports
