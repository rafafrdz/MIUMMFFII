module Foreign.Safe (module Exports) where

import "base" Foreign.Safe as Exports
