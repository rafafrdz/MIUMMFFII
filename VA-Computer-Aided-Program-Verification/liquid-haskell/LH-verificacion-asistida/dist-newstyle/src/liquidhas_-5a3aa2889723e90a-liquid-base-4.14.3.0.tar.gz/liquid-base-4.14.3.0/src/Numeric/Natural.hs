module Numeric.Natural (module Exports) where

import "base" Numeric.Natural as Exports
