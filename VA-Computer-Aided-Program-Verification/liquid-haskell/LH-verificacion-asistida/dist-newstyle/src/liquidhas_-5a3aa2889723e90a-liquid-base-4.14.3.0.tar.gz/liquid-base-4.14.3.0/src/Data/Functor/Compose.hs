module Data.Functor.Compose (module Exports) where

import "base" Data.Functor.Compose as Exports
