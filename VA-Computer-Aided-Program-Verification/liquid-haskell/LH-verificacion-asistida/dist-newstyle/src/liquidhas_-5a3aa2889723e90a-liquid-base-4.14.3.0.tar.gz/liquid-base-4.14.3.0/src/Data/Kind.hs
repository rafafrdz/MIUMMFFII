module Data.Kind (module Exports) where

import "base" Data.Kind as Exports
