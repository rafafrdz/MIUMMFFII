module Text.Read.Lex (module Exports) where

import "base" Text.Read.Lex as Exports
