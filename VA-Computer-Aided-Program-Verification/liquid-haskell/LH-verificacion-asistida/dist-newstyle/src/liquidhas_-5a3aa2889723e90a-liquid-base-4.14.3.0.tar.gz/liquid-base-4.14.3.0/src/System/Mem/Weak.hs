module System.Mem.Weak (module Exports) where

import "base" System.Mem.Weak as Exports
