module Foreign.StablePtr (module Exports) where

import "base" Foreign.StablePtr as Exports
