module Data.Int ( module Exports ) where

import GHC.Int
import "base" Data.Int as Exports
