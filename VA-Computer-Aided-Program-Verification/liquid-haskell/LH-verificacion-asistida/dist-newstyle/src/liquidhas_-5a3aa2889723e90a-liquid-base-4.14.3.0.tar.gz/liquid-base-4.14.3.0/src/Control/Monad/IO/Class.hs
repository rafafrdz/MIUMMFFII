module Control.Monad.IO.Class (module Exports) where

import "base" Control.Monad.IO.Class as Exports
