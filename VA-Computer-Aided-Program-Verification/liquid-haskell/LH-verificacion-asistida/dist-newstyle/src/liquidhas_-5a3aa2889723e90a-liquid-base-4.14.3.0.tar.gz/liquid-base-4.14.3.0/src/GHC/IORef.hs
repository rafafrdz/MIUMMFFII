module GHC.IORef (module Exports) where

import "base" GHC.IORef as Exports
