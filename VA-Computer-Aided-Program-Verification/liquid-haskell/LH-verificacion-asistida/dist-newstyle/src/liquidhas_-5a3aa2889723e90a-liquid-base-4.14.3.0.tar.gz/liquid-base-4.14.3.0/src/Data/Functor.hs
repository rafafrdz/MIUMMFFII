module Data.Functor ( module Exports ) where

import "base" Data.Functor as Exports
