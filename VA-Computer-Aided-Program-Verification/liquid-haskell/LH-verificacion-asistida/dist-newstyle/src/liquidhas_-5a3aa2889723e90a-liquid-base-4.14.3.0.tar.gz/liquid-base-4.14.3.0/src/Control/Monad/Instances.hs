module Control.Monad.Instances (module Exports) where

import "base" Control.Monad.Instances as Exports
