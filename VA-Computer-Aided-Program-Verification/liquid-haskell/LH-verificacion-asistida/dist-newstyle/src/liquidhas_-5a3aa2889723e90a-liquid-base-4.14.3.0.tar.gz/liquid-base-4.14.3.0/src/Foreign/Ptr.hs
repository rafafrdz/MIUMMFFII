module Foreign.Ptr (module Exports) where

import GHC.Ptr
import "base" Foreign.Ptr as Exports
