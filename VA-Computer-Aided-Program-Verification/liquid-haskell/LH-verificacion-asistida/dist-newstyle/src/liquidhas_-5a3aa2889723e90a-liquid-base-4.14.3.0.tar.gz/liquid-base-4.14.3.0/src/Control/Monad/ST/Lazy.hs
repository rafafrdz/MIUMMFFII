module Control.Monad.ST.Lazy (module Exports) where

import "base" Control.Monad.ST.Lazy as Exports
