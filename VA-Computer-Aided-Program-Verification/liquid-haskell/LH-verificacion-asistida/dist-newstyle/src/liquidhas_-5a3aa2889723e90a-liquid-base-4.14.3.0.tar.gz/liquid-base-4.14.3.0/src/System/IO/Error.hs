module System.IO.Error (module Exports) where

import "base" System.IO.Error as Exports
