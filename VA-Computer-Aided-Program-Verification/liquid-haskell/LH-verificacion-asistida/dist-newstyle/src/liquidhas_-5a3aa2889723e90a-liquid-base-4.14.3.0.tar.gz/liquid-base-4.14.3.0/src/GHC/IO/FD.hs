module GHC.IO.FD (module Exports) where

import "base" GHC.IO.FD as Exports
