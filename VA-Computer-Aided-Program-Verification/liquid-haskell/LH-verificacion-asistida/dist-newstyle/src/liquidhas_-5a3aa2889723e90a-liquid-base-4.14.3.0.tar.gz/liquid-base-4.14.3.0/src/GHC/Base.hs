module GHC.Base (module Exports) where

import GHC.Types
import GHC.CString
import GHC.Classes
import GHC.Tuple

import "base" GHC.Base as Exports
