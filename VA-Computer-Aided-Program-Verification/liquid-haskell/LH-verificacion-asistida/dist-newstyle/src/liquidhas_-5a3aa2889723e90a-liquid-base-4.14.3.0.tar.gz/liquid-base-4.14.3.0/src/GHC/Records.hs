module GHC.Records (module Exports) where

import "base" GHC.Records as Exports
