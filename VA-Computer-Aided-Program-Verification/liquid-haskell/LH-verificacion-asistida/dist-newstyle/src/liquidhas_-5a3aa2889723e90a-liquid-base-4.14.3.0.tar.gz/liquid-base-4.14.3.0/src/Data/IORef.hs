module Data.IORef (module Exports ) where

import GHC.Base
import "base" Data.IORef as Exports

