module Control.Monad ( module Exports ) where

import GHC.Base
import "base" Control.Monad as Exports
