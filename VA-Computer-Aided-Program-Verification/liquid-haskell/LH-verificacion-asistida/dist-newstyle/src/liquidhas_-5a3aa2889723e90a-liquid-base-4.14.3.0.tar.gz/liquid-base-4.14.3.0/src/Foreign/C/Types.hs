module Foreign.C.Types (module Exports) where

import GHC.Base
import GHC.Word
import "base" Foreign.C.Types as Exports
