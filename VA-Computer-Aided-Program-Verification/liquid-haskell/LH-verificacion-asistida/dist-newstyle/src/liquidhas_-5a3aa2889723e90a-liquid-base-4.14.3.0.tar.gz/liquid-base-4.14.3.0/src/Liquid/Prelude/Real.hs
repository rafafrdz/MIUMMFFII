module Liquid.Prelude.Real where

import GHC.Num
