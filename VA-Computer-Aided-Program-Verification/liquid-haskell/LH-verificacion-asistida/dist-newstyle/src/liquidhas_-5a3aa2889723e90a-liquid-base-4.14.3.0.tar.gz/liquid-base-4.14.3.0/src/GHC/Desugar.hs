module GHC.Desugar (module Exports) where

import "base" GHC.Desugar as Exports
