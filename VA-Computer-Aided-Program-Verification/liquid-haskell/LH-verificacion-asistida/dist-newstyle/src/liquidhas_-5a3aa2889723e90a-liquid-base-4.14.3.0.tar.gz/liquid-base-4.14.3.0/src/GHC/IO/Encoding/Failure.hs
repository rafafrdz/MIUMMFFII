module GHC.IO.Encoding.Failure (module Exports) where

import "base" GHC.IO.Encoding.Failure as Exports
