module Data.Function ( module Exports) where

import "base" Data.Function as Exports
