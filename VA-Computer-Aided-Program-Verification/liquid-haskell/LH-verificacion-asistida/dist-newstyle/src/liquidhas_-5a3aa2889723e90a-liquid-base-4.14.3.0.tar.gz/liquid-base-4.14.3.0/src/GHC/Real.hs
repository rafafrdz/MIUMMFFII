module GHC.Real (module Exports) where

import GHC.Types
import GHC.Num
import "base" GHC.Enum
import "base" GHC.Real as Exports
