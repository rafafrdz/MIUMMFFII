module Data.List ( module Exports) where

import Data.Char
import "base" Data.List as Exports
