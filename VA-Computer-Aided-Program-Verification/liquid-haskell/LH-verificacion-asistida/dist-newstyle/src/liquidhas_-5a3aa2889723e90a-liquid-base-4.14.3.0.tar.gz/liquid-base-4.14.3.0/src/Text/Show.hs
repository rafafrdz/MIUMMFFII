module Text.Show (module Exports) where

import "base" Text.Show as Exports
