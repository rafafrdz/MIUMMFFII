module Control.Category (module Exports) where

import "base" Control.Category as Exports
