module GHC.TopHandler (module Exports) where

import "base" GHC.TopHandler as Exports
