module Unsafe.Coerce (module Exports) where

import "base" Unsafe.Coerce as Exports
