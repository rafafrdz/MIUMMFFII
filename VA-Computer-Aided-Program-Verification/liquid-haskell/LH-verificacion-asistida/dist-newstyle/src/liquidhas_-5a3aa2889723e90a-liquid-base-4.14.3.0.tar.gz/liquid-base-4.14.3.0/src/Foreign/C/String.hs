module Foreign.C.String (module Exports) where

import Foreign.Ptr
import "base" Foreign.C.String as Exports
