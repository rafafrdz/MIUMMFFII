module GHC.IO.Handle ( module Exports ) where

import GHC.Types
import GHC.Integer
import "base" GHC.IO.Handle as Exports
