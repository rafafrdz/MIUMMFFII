module Foreign.Marshal.Array (module Exports) where

import "base" Foreign.Marshal.Array as Exports
