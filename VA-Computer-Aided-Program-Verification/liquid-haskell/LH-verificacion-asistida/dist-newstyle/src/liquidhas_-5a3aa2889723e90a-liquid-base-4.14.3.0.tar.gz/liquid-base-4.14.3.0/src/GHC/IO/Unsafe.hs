module GHC.IO.Unsafe (module Exports) where

import "base" GHC.IO.Unsafe as Exports
