module GHC.IO.Handle.Lock (module Exports) where

import "base" GHC.IO.Handle.Lock as Exports
