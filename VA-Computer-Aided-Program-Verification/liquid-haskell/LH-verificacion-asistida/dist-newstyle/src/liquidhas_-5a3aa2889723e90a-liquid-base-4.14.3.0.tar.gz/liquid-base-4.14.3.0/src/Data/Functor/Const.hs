module Data.Functor.Const (module Exports) where

import "base" Data.Functor.Const as Exports
