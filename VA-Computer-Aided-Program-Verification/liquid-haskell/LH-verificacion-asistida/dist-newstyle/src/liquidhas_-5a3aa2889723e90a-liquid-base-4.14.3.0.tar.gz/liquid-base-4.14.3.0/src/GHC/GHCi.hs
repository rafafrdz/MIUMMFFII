module GHC.GHCi (module Exports) where

import "base" GHC.GHCi as Exports
