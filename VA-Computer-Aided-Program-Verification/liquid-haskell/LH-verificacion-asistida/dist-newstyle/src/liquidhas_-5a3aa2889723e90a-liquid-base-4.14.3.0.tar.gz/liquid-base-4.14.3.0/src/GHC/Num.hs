module GHC.Num (module Exports) where

import GHC.Base
import "base" GHC.Num as Exports
