module Control.Monad.Zip (module Exports) where

import "base" Control.Monad.Zip as Exports
