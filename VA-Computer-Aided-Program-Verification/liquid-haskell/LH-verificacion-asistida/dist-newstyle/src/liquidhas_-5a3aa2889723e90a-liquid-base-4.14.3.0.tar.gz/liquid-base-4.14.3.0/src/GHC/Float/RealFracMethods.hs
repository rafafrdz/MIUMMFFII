module GHC.Float.RealFracMethods (module Exports) where

import "base" GHC.Float.RealFracMethods as Exports
