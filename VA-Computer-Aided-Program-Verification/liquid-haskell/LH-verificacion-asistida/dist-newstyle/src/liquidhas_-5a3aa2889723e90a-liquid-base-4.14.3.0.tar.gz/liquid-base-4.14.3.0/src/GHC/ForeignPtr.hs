module GHC.ForeignPtr ( module Exports ) where

import GHC.Base
import "base" GHC.ForeignPtr as Exports
