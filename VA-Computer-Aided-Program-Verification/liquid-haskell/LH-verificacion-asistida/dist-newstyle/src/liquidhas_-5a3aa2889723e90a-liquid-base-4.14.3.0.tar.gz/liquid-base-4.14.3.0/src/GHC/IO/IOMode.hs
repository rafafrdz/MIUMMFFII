module GHC.IO.IOMode (module Exports) where

import "base" GHC.IO.IOMode as Exports
