module GHC.Fingerprint.Type (module Exports) where

import "base" GHC.Fingerprint.Type as Exports
