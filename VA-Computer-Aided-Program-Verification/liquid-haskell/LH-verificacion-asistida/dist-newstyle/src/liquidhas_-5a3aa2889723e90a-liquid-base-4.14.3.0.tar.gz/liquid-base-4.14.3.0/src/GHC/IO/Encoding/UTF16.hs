module GHC.IO.Encoding.UTF16 (module Exports) where

import "base" GHC.IO.Encoding.UTF16 as Exports
