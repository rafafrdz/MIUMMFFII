module Control.Concurrent.MVar (module Exports) where

import "base" Control.Concurrent.MVar as Exports
