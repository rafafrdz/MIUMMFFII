module GHC.Clock (module Exports) where

import "base" GHC.Clock as Exports
