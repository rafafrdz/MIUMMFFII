module GHC.IO.Encoding.UTF8 (module Exports) where

import "base" GHC.IO.Encoding.UTF8 as Exports
