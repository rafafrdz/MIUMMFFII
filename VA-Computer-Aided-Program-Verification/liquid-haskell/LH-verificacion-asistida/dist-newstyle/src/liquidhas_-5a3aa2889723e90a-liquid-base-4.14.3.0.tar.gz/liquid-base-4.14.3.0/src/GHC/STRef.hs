module GHC.STRef (module Exports) where

import "base" GHC.STRef as Exports
