module GHC.Ix (module Exports) where

import "base" GHC.Ix as Exports
