module System.IO.Unsafe (module Exports) where

import "base" System.IO.Unsafe as Exports
