module Data.Functor.Product (module Exports) where

import "base" Data.Functor.Product as Exports
