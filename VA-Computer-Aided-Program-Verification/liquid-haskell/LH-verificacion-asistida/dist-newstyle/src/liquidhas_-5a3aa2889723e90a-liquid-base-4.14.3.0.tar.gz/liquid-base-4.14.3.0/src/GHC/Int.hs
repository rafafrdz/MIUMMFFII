module GHC.Int (module Exports) where

import GHC.Base
import "base" GHC.Int as Exports
