module Control.Exception.Base (module Exports) where

import GHC.Base
import "base" Control.Exception.Base as Exports
