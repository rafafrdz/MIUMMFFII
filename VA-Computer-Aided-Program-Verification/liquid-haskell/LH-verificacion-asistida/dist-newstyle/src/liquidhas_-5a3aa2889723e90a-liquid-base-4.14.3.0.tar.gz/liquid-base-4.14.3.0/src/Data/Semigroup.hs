module Data.Semigroup (module Exports) where

import "base" Data.Semigroup as Exports
