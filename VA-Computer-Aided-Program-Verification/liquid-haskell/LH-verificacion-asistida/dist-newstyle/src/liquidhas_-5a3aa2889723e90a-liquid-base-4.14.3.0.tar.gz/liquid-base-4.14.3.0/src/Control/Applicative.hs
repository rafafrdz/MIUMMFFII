module Control.Applicative ( module Exports ) where

import GHC.Base
import "base" Control.Applicative as Exports
