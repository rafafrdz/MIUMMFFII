module Foreign.C.Error (module Exports) where

import "base" Foreign.C.Error as Exports
