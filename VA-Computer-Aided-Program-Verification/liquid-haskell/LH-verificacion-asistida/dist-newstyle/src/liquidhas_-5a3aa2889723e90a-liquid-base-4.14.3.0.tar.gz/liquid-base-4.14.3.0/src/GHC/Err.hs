module GHC.Err (module Exports) where

import "base" GHC.Err as Exports
