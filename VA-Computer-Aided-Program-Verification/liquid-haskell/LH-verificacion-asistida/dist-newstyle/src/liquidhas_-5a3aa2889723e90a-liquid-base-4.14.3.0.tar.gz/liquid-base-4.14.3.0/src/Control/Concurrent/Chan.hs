module Control.Concurrent.Chan (module Exports) where

import "base" Control.Concurrent.Chan as Exports
