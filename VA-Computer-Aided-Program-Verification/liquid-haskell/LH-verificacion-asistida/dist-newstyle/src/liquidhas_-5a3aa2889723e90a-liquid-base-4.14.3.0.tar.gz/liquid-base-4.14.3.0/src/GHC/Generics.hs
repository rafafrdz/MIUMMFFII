module GHC.Generics ( module Exports ) where

import GHC.Base
import "base" GHC.Generics as Exports
