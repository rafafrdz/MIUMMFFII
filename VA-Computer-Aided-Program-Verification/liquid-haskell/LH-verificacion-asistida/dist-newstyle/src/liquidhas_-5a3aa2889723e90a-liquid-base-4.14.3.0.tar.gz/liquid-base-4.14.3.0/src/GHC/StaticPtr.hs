module GHC.StaticPtr (module Exports) where

import "base" GHC.StaticPtr as Exports
