module GHC.IO.Encoding.CodePage (module Exports) where

import "base" GHC.IO.Encoding.CodePage as Exports
