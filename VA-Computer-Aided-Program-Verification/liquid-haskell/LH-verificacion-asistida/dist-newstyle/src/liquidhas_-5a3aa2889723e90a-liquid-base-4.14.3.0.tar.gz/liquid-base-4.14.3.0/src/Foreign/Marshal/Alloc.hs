module Foreign.Marshal.Alloc (module Exports) where

import GHC.Types
import GHC.Ptr

import "base" Foreign.Marshal.Alloc as Exports

