module GHC.Stack (module Exports) where

import "base" GHC.Stack as Exports
