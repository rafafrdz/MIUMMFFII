module Data.Void (module Exports) where

import "base" Data.Void as Exports
