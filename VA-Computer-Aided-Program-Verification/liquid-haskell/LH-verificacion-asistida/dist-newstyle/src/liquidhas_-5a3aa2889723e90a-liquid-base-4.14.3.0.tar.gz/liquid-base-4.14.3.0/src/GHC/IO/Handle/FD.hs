module GHC.IO.Handle.FD (module Exports) where

import "base" GHC.IO.Handle.FD as Exports
