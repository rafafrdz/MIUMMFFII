module Data.STRef (module Exports) where

import "base" Data.STRef as Exports
