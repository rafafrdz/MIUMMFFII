module GHC.TypeLits ( module Exports ) where

import GHC.Base
import "base" GHC.TypeLits as Exports
