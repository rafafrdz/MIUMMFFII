module GHC.MVar (module Exports) where

import "base" GHC.MVar as Exports
