module Data.Ix (module Exports) where

import "base" Data.Ix as Exports
