module GHC.Pack (module Exports) where

import "base" GHC.Pack as Exports
