module System.Environment.Blank (module Exports) where

import "base" System.Environment.Blank as Exports
