module GHC.IO.Handle.Types (module Exports) where

import "base" GHC.IO.Handle.Types as Exports
