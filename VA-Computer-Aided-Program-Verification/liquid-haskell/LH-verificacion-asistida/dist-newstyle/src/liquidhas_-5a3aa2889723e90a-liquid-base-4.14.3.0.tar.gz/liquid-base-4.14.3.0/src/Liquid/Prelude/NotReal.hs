module Liquid.Prelude.NotReal where

import GHC.Num
import GHC.Real
