module GHC.Fingerprint (module Exports) where

import "base" GHC.Fingerprint as Exports
