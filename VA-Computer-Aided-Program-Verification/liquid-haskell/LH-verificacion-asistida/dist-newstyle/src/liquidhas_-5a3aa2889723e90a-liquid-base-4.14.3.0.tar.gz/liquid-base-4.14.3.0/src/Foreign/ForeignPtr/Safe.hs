module Foreign.ForeignPtr.Safe (module Exports) where

import "base" Foreign.ForeignPtr.Safe as Exports
