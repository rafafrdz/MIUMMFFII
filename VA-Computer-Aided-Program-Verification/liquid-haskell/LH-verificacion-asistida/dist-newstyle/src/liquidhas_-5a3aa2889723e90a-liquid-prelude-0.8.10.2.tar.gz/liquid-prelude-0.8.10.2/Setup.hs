module Main where

import Language.Haskell.Liquid.Cabal (liquidHaskellMain)

main :: IO ()
main = liquidHaskellMain
